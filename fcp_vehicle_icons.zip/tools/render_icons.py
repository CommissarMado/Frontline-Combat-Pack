#!/usr/bin/env python3
# render_icons.py - build-time isometric vehicle-icon renderer for FCP.
#   ./gradlew renderVehicleIcons            (all vehicles)
#   python3 tools/render_icons.py --batch . [id1,id2,...]
#   python3 tools/render_icons.py <geo> <tex> <out> [yaw] [pitch]
# See tools/RENDER_ICONS_README.md. Requires numpy + Pillow.
"""Build-time isometric renderer for SBW/GeckoLib .geo.json vehicle models.
Rasterizes each model with its texture into a tightly-cropped isometric PNG.
Pure Python + numpy + Pillow. No game / Blockbench needed."""
import json, math, os, sys
import numpy as np
from PIL import Image

DEG = math.pi / 180.0

# ---------------- rotation helpers ----------------
def rot_x(a):
    c,s=math.cos(a),math.sin(a)
    return np.array([[1,0,0],[0,c,-s],[0,s,c]],float)
def rot_y(a):
    c,s=math.cos(a),math.sin(a)
    return np.array([[c,0,s],[0,1,0],[-s,0,c]],float)
def rot_z(a):
    c,s=math.cos(a),math.sin(a)
    return np.array([[c,-s,0],[s,c,0],[0,0,1]],float)

# Bedrock/GeckoLib euler: configurable order+signs (calibrated below)
CONV=("ZYX",-1,-1,1)
def euler_geo(rx,ry,rz):
    order,sx,sy,sz=CONV
    Rx=rot_x(sx*rx*DEG); Ry=rot_y(sy*ry*DEG); Rz=rot_z(sz*rz*DEG)
    M={'X':Rx,'Y':Ry,'Z':Rz}
    a,b,c=order  # matrix = M[a]@M[b]@M[c]  (c applied first)
    return M[a]@M[b]@M[c]

# ---------------- geo parsing + world verts ----------------
def load_geo(path):
    d=json.load(open(path,encoding='utf-8-sig'))
    g=d['minecraft:geometry'][0]
    desc=g['description']
    tw=desc.get('texture_width',16); th=desc.get('texture_height',16)
    bones={b['name']:b for b in g['bones']}
    return g['bones'], bones, tw, th

def bone_world(bone, bones, cache):
    """4x4 matrix mapping bone-pivot-local coords to model space."""
    name=bone['name']
    if name in cache: return cache[name]
    piv=np.array(bone.get('pivot',[0,0,0]),float); piv=piv*np.array([-1,1,1])
    rot=bone.get('rotation',[0,0,0])
    R=euler_geo(*rot)
    parent=bone.get('parent')
    M=np.eye(4)
    if parent and parent in bones:
        Mp=bone_world(bones[parent],bones,cache)
        ppiv=np.array(bones[parent].get('pivot',[0,0,0]),float)*np.array([-1,1,1])
        T=np.eye(4); T[:3,3]=piv-ppiv
        Rr=np.eye(4); Rr[:3,:3]=R
        M=Mp@T@Rr
    else:
        T=np.eye(4); T[:3,3]=piv
        Rr=np.eye(4); Rr[:3,:3]=R
        M=T@Rr
    cache[name]=M
    return M

# cube faces: name -> (4 corner indices, ) using corner numbering below.
# corners: bit0=x(0=min,1=max), bit1=y, bit2=z
def corners(mn,mx):
    c=np.zeros((8,3))
    for i in range(8):
        c[i]=[mx[0] if i&1 else mn[0], mx[1] if i&2 else mn[1], mx[2] if i&4 else mn[2]]
    return c
# face -> (v00,v10,v11,v01) in an order where (s,t): s along U, t along V (t down)
FACES={
 'north':([1,0,4,5],(0,0,-1)),   # -Z  (looking toward -Z from outside): x from max->min
 'south':([0,1,5,4],(0,0, 1)),   # +Z
 'east' :([0,4,6,2],(1,0,0)),    # wait east is +X
 'west' :([5,1,3,7],(-1,0,0)),
 'up'   :([2,6,7,3],(0,1,0)),    # +Y  top
 'down' :([0,1,3,2],(0,-1,0)),
}
# We'll refine face corner orders during calibration.
# Above indices reference the 8 corners.

def cube_faces(cube):
    origin=np.array(cube['origin'],float); size=np.array(cube['size'],float)
    inf=cube.get('inflate',0.0)
    mn=origin-inf; mx=origin+size+inf
    cs=corners(mn,mx)
    # per-cube rotation about pivot (model space)
    if 'rotation' in cube:
        R=euler_geo(*cube['rotation'])
        piv=np.array(cube.get('pivot',[0,0,0]),float)
        cs=(R@(cs-piv).T).T+piv
    return cs

# proper face corner definitions (min/max box, before rotation): use explicit vertex coords
def face_geometry(cube):
    origin=np.array(cube['origin'],float); size=np.array(cube['size'],float)
    inf=cube.get('inflate',0.0)
    mirror=bool(cube.get('mirror',False))
    # GeckoLib mirrors X into the origin: x' = -(ox+sx); build the 8-vertex box from there
    ox=-(origin[0]+size[0])
    x0=ox-inf; x1=ox+size[0]+inf
    y0=origin[1]-inf; y1=origin[1]+size[1]+inf
    z0=origin[2]-inf; z1=origin[2]+size[2]+inf
    # VertexSet (GeckoLib naming: Back=minX, Front=maxX, Left=minZ, Right=maxZ)
    bLB=(x0,y0,z0); bRB=(x0,y0,z1); tLB=(x0,y1,z0); tRB=(x0,y1,z1)
    tLF=(x1,y1,z0); tRF=(x1,y1,z1); bLF=(x1,y0,z0); bRF=(x1,y0,z1)
    qW=[tRB,tLB,bLB,bRB]; qE=[tLF,tRF,bRF,bLF]
    qN=[tLB,tLF,bLF,bLB]; qS=[tRF,tRB,bRB,bRF]
    qU=[tRB,tRF,tLF,tLB]; qD=[bLB,bLF,bRF,bRB]
    # verticesForQuad (isBoxUvs=False): mirror swaps WEST<->EAST and UP<->DOWN vertex sets
    if not mirror:
        faces={'west':qW,'east':qE,'north':qN,'south':qS,'up':qU,'down':qD}
    else:
        faces={'west':qE,'east':qW,'north':qN,'south':qS,'up':qD,'down':qU}
    cx=(x0+x1)/2; cy=(y0+y1)/2; cz=(z0+z1)/2; center=np.array([cx,cy,cz])
    out={}
    for f,verts in faces.items():
        pts=np.array(verts,float)
        # outward normal from the axis-aligned box (constant axis, pointing away from cube center)
        fc=pts.mean(0); dvec=fc-center
        n=np.zeros(3); ax=int(np.argmax(np.abs(dvec))); n[ax]=np.sign(dvec[ax]) or 1.0
        if 'rotation' in cube:
            R=euler_geo(*cube['rotation']); piv=np.array(cube.get('pivot',[0,0,0]),float); piv[0]=-piv[0]
            pts=(R@(pts-piv).T).T+piv; n=R@n
        out[f]=(pts,n)
    return out

# ---------------- projection ----------------
def iso_matrix(yaw_deg, pitch_deg):
    return rot_x(pitch_deg*DEG) @ rot_y(yaw_deg*DEG)

CULL=True
DEPTH_BIAS=0.0
def render(geo_path, tex_path, yaw=225.0, pitch=30.0, scale=10.0, out_size=None, highlight=None, only=None):
    bones_list, bones, tw, th = load_geo(geo_path)
    tex=np.array(Image.open(tex_path).convert('RGBA'))
    cache={}
    V=iso_matrix(yaw,pitch)   # view rotation (model->view)
    # gather all faces -> screen tris
    tris=[]  # (screen xy [3x2], depth[3], uvpix[3x2], shade)
    for bone in bones_list:
        if only is not None and bone['name'] not in only: continue
        _hl = highlight is not None and bone['name'] in highlight
        M=bone_world(bone,bones,cache)
        piv=np.array(bone.get('pivot',[0,0,0]),float)*np.array([-1,1,1])
        for cube in bone.get('cubes',[]):
            uv=cube.get('uv')
            faces=face_geometry(cube)
            Mrot=M[:3,:3]
            for fname,(pts,normal) in faces.items():
                pl=pts-piv
                ph=np.hstack([pl,np.ones((4,1))])
                world=(M@ph.T).T[:,:3]
                vv=(V@world.T).T
                # true outward normal for this face (hardcoded axis dir, rotated by cube+bone), to view
                nv=V@(Mrot@normal)
                nl=np.linalg.norm(nv)
                if nl < 1e-9: continue
                nv=nv/nl
                fu=get_face_uv(uv,fname,cube)
                if fu is None: continue
                # GeckoLib renders NoCull (double-sided) -> render every UV'd face so single-sided
                # panels (canopies) show. Depth-bias along the CORRECT outward normal makes exterior
                # faces win z-fights vs interior faces of the same/other cubes (no interior bleed).
                sx=vv[:,0]*scale; sy=-vv[:,1]*scale
                depth=vv[:,2] + DEPTH_BIAS*float(nv[2])
                shade=shade_face(nv if nv[2]>=0 else -nv)
                quad_xy=np.stack([sx,sy],1)
                for a,b,c in [(0,1,2),(0,2,3)]:
                    tris.append((quad_xy[[a,b,c]], depth[[a,b,c]], fu[[a,b,c]], shade, _hl))
    return rasterize(tris, tex, tw, th)

def get_face_uv(uv, fname, cube):
    # GeckoLib per-face UV: direction->uv directly (no key swap); for non-mirrored faces GeckoLib
    # swaps u<->uWidth (U flipped). Maps to the verticesForQuad vertex order.
    if not isinstance(uv,dict) or fname not in uv: return None
    f=uv[fname]; u0,v0=f['uv']; us,vs=f['uv_size']
    if not bool(cube.get('mirror',False)):
        return np.array([[u0+us,v0],[u0,v0],[u0,v0+vs],[u0+us,v0+vs]],float)
    return np.array([[u0,v0],[u0+us,v0],[u0+us,v0+vs],[u0,v0+vs]],float)

def shade_face(nv):
    n=nv/(np.linalg.norm(nv)+1e-9)
    L=np.array([-0.35,0.88,0.32]); L=L/np.linalg.norm(L)   # key light: top, slight front-left
    diff=max(0.0,float(n@L))
    # ambient + strong directional, plus a small side bias so the two verticals read distinctly
    val=0.42+0.62*diff - 0.06*max(0.0,float(n[0]))
    return float(np.clip(val,0.34,1.0))

def rasterize(tris, tex, tw, th):
    if not tris: return None
    allxy=np.concatenate([t[0] for t in tris],0)
    minx,miny=np.floor(allxy.min(0)).astype(int); maxx,maxy=np.ceil(allxy.max(0)).astype(int)
    W=maxx-minx+2; H=maxy-miny+2
    img=np.zeros((H,W,4),float); zbuf=np.full((H,W),-1e18)
    thh,tww=tex.shape[0],tex.shape[1]
    for xy,depth,uvpix,shade,hl in tris:
        p=xy-np.array([minx,miny])
        x0=int(max(0,math.floor(p[:,0].min()))); x1=int(min(W-1,math.ceil(p[:,0].max())))
        y0=int(max(0,math.floor(p[:,1].min()))); y1=int(min(H-1,math.ceil(p[:,1].max())))
        if x1<x0 or y1<y0: continue
        xs=np.arange(x0,x1+1); ys=np.arange(y0,y1+1)
        gx,gy=np.meshgrid(xs+0.5,ys+0.5)
        x1_,y1_=p[0]; x2_,y2_=p[1]; x3_,y3_=p[2]
        d=(y2_-y3_)*(x1_-x3_)+(x3_-x2_)*(y1_-y3_)
        if abs(d)<1e-9: continue
        l1=((y2_-y3_)*(gx-x3_)+(x3_-x2_)*(gy-y3_))/d
        l2=((y3_-y1_)*(gx-x3_)+(x1_-x3_)*(gy-y3_))/d
        l3=1-l1-l2
        inside=(l1>=-0.001)&(l2>=-0.001)&(l3>=-0.001)
        if not inside.any(): continue
        zz=l1*depth[0]+l2*depth[1]+l3*depth[2]
        uu=l1*uvpix[0,0]+l2*uvpix[1,0]+l3*uvpix[2,0]
        vv=l1*uvpix[0,1]+l2*uvpix[1,1]+l3*uvpix[2,1]
        sub=zbuf[y0:y1+1,x0:x1+1]
        better=inside&(zz>sub)
        if not better.any(): continue
        ui=np.clip(uu.astype(int),0,tww-1); vi=np.clip(vv.astype(int),0,thh-1)
        texel=tex[vi,ui].astype(float)
        # alpha test
        better&=texel[...,3]>10
        if not better.any(): continue
        rgb=texel.copy(); rgb[...,:3]*=shade
        if hl:
            rgb[...,0]=np.clip(rgb[...,0]*0.3+180,0,255); rgb[...,1]*=0.2; rgb[...,2]*=0.2
        tgt=img[y0:y1+1,x0:x1+1]
        tgt[better]=rgb[better]
        sub[better]=zz[better]
    # crop to content
    a=img[...,3]
    ys,xs=np.where(a>0)
    if len(xs)==0: return None
    crop=img[ys.min():ys.max()+1, xs.min():xs.max()+1]
    return Image.fromarray(np.clip(crop,0,255).astype('uint8'),'RGBA')

def _single_main():
    geo=sys.argv[1]; tex=sys.argv[2]; out=sys.argv[3]
    yaw=float(sys.argv[4]) if len(sys.argv)>4 else 135.0
    pitch=float(sys.argv[5]) if len(sys.argv)>5 else 35.264
    im=render(geo,tex,yaw=yaw,pitch=pitch,scale=10.0)
    if im: im.save(out); print("saved",out,im.size)
    else: print("empty render")

# ============================ BATCH DRIVER ============================
import glob as _glob

def _entity_textures(root):
    """id -> authoritative default texture path, via ModEntities (id->class) + <Class>.CAMO_TEXTURES[0]."""
    import re
    me_path=os.path.join(root,'src/main/java/frontline/combat/fcp/init/ModEntities.java')
    if not os.path.exists(me_path): return {}
    me=open(me_path,encoding='utf-8',errors='ignore').read()
    id2cls={vid:cls for cls,vid in re.findall(r'EntityType<(\w+)>>\s*\w+\s*=\s*register\("([a-z0-9_]+)"', me)}
    clsfiles={}
    for f in _glob.glob(os.path.join(root,'src/main/java/**/*.java'),recursive=True):
        clsfiles[os.path.basename(f)[:-5]]=f
    out={}
    for vid,cls in id2cls.items():
        f=clsfiles.get(cls)
        if not f: continue
        cs=open(f,encoding='utf-8',errors='ignore').read()
        m=re.search(r'(CAMO_TEXTURES|TEXTURES|getCamoTextures)[\s\S]{0,80}?\{([\s\S]*?)\}', cs)
        block=m.group(2) if m else cs
        rl=re.search(r'new ResourceLocation\(\s*"(\w+)"\s*,\s*"([^"]+\.png)"', block)
        if rl:
            ns,path=rl.group(1),rl.group(2)
            base='src/main/resources/assets/%s'%ns
            out[vid]=os.path.join(root,base,path)
    return out

def _resolve_vehicles(root):
    """vehicle-id -> (geo_path, texture_path). GEO from SBW item json (reliable) or <id> geo file.
    TEXTURE from folder heuristic (item-json textures are often stale). Overrides win."""
    A=os.path.join(root,'src/main/resources/assets/fcp')
    def apath(rl): return os.path.join(A, rl.split(':',1)[-1])
    item={}   # id -> (geoRL, texRL) from item jsons
    for jp in _glob.glob(os.path.join(A,'sbw/**/*.json'),recursive=True):
        try: d=json.load(open(jp,encoding='utf-8-sig'))
        except Exception: continue
        vid=d.get('ID','').split(':')[-1]; m=d.get('Model',{})
        if vid: item[vid]=(m.get('Model'), m.get('Texture'))
    # candidate ids = item ids + geo filenames
    ids=set(item)
    for gp in _glob.glob(os.path.join(A,'geo/*.json')):
        ids.add(os.path.basename(gp)[:-5].replace('.geo',''))
    ent_tex=_entity_textures(root)
    all_tex=[t for t in _glob.glob(os.path.join(A,'textures/entity/**/*.png'),recursive=True) if 'wreck' not in t.lower()]
    def find_geo(vid):
        if vid in item and item[vid][0]:
            p=apath(item[vid][0])
            if os.path.exists(p): return p
        for cand in (f'geo/{vid}.geo.json', f'geo/{vid}.json'):
            p=os.path.join(A,cand)
            if os.path.exists(p): return p
        return None
    def find_tex(vid):
        # 0) authoritative: entity class CAMO_TEXTURES[0]
        if vid in ent_tex and os.path.exists(ent_tex[vid]): return ent_tex[vid]
        # 1) exact folder
        c=[t for t in all_tex if f'/entity/{vid}/' in t.replace('\\','/')]
        if c: return sorted(c)[0]
        # 2) filename/path contains full id
        c=[t for t in all_tex if vid in os.path.basename(t).lower()]
        if c: return sorted(c)[0]
        c=[t for t in all_tex if vid in t.replace('\\','/').lower()]
        if c: return sorted(c)[0]
        # 3) item-json texture if it exists
        if vid in item and item[vid][1]:
            p=apath(item[vid][1])
            if os.path.exists(p): return p
        # 4) progressively shorter prefix (variant sharing a base skin)
        parts=vid.split('_')
        for k in range(len(parts)-1,0,-1):
            pref='_'.join(parts[:k])
            c=[t for t in all_tex if pref in t.replace('\\','/').lower()]
            if c: return sorted(c)[0]
        return None
    res={}
    for vid in ids:
        g=find_geo(vid); t=find_tex(vid)
        if g and t: res[vid]=(g,t)
    ov=os.path.join(root,'tools/icon_overrides.json')
    if os.path.exists(ov):
        for vid,info in json.load(open(ov)).items():
            cur=res.get(vid,(None,None))
            g=os.path.join(root,info['geo']) if 'geo' in info else (cur[0] or find_geo(vid))
            t=os.path.join(root,info['texture']) if 'texture' in info else (cur[1] or find_tex(vid))
            if g and t: res[vid]=(g,t)
    return res

def _square_canvas(im, size=128, fit=120):
    """Scale model to fit within `fit` px (preserve aspect), center on size x size transparent canvas (SBW format)."""
    w,h=im.size; r=min(fit/w, fit/h, 1.0) if max(w,h)>fit else fit/max(w,h)
    nw,nh=max(1,int(round(w*r))), max(1,int(round(h*r)))
    im=im.resize((nw,nh), Image.NEAREST)
    canvas=Image.new('RGBA',(size,size),(0,0,0,0))
    canvas.alpha_composite(im, ((size-nw)//2, (size-nh)//2))
    return canvas

def batch(root, ids=None, yaw=135.0, pitch=35.264, scale=None, max_dim=128):
    out_dir=os.path.join(root,'src/main/resources/assets/superbwarfare/textures/vehicle_icon/container')
    os.makedirs(out_dir,exist_ok=True)
    veh=_resolve_vehicles(root)
    # optional per-vehicle angle overrides in icon_overrides.json: {"id":{...,"yaw":N,"pitch":N}}
    angles={}
    _ov=os.path.join(root,'tools/icon_overrides.json')
    if os.path.exists(_ov):
        for vid,info in json.load(open(_ov)).items():
            if 'yaw' in info or 'pitch' in info:
                angles[vid]=(info.get('yaw',yaw), info.get('pitch',pitch))
    todo=sorted(ids) if ids else sorted(veh)
    ok=0; miss=[]
    for vid in todo:
        if vid not in veh: miss.append(vid); continue
        geo,tex=veh[vid]
        if not (os.path.exists(geo) and os.path.exists(tex)): miss.append(vid); continue
        try:
            vy,vp=angles.get(vid,(yaw,pitch))
            im=render(geo,tex,yaw=vy,pitch=vp,scale=4.5)
            if im is None: miss.append(vid); continue
            im=_square_canvas(im, max_dim, fit=int(max_dim*0.94))
            im.save(os.path.join(out_dir,f'{vid}.png')); ok+=1
        except Exception as e:
            miss.append(f'{vid}({e})')
    print(f'[render_icons] wrote {ok} icons to {out_dir}')
    if miss: print(f'[render_icons] unresolved ({len(miss)}): '+', '.join(miss[:40]))
    return ok

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--batch':
        root=sys.argv[2] if len(sys.argv)>2 else '.'
        ids=sys.argv[3].split(',') if len(sys.argv)>3 else None
        batch(root, ids)
    else:
        _single_main()

package frontline.combat.fcp.init;

import frontline.combat.fcp.FCP;
import frontline.combat.fcp.client.overlay.FcpPilotOverlay;
import frontline.combat.fcp.client.renderer.Aavp.AAVPRenderer;
import frontline.combat.fcp.client.renderer.Abrams.M1a1Renderer;
import frontline.combat.fcp.client.renderer.Abrams.M1a2Renderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp1.BMP1AMRenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp1.BMP1Renderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp1.BMP1URenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp2.BMP2Renderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp1.BMP1PRenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp2.BMP2DRenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp2.BMP2MRenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp2.BMP2NoAtgmRenderer;
import frontline.combat.fcp.client.renderer.Bmp.Bmp2.BMP2MDRenderer;
import frontline.combat.fcp.client.renderer.Btr.BTR82Renderer;
import frontline.combat.fcp.client.renderer.Btr.BTR82ATRenderer;
import frontline.combat.fcp.client.renderer.Btr.BTR3ERenderer;
import frontline.combat.fcp.client.renderer.Btr.BTR4MV1Renderer;
import frontline.combat.fcp.client.renderer.Btr.BTR80Renderer;
import frontline.combat.fcp.client.renderer.Btr.BTR80CopeRenderer;
import frontline.combat.fcp.client.renderer.Btr.BTR82CopeRenderer;
import frontline.combat.fcp.client.renderer.Fmtv.FMTVRenderer;
import frontline.combat.fcp.client.renderer.GazTigr.GazTigrGLRenderer;
import frontline.combat.fcp.client.renderer.GazTigr.GazTigrDualRenderer;
import frontline.combat.fcp.client.renderer.GazTigr.GazTigrMGRenderer;
import frontline.combat.fcp.client.renderer.GazTigr.GazTigrRWSRenderer;
import frontline.combat.fcp.client.renderer.GazTigr.GazTigrRenderer;
import frontline.combat.fcp.client.renderer.Huey.HueyRenderer;
import frontline.combat.fcp.client.renderer.Huey.HueyM60DoorGunsRenderer;
import frontline.combat.fcp.client.renderer.Huey.HueyM60GunshipRenderer;
import frontline.combat.fcp.client.renderer.Huey.HueyM134DoorGunsRenderer;
import frontline.combat.fcp.client.renderer.Huey.HueyM134GunshipRenderer;
import frontline.combat.fcp.client.renderer.Huey.VenomRenderer;
import frontline.combat.fcp.client.renderer.Huey.VenomGunshipRenderer;
import frontline.combat.fcp.client.renderer.Huey.VenomDoorGunsRenderer;
import frontline.combat.fcp.client.renderer.JohnDeere.CombineRenderer;
import frontline.combat.fcp.client.renderer.JohnDeere.CultivatorRenderer;
import frontline.combat.fcp.client.renderer.Humvee.HumveeUnarmedRenderer;
import frontline.combat.fcp.client.renderer.JohnDeere.JohnDeereRenderer;
import frontline.combat.fcp.client.renderer.JohnDeere.SeederRenderer;
import frontline.combat.fcp.client.renderer.Kamaz.KamazRenderer;
import frontline.combat.fcp.client.renderer.Lav.Lav25Renderer;
import frontline.combat.fcp.client.renderer.Littlebird.Ah6mLittlebirdRenderer;
import frontline.combat.fcp.client.renderer.Littlebird.LittlebirdArmedRenderer;
import frontline.combat.fcp.client.renderer.Littlebird.LittlebirdRenderer;
import frontline.combat.fcp.client.renderer.M109.M109Renderer;
import frontline.combat.fcp.client.renderer.Matv.MATV9In1Renderer;
import frontline.combat.fcp.client.renderer.Matv.MATVCrowsRenderer;
import frontline.combat.fcp.client.renderer.Matv.MATVRenderer;
import frontline.combat.fcp.client.renderer.Matv.MATVTOWRenderer;
import frontline.combat.fcp.client.renderer.Rg33.RG33Renderer;
import frontline.combat.fcp.client.renderer.MemeVehicles.BigBirdRenderer;
import frontline.combat.fcp.client.renderer.MemeVehicles.WolfRenderer;
import frontline.combat.fcp.client.renderer.Mi17.MI17Renderer;
import frontline.combat.fcp.client.renderer.Msta.MstaRenderer;
import frontline.combat.fcp.client.renderer.Novator.NovatorRenderer;
import frontline.combat.fcp.client.renderer.NovatorUnarmed.NovatorUnarmedRenderer;
import frontline.combat.fcp.client.renderer.Dpv.DpvM240Renderer;
import frontline.combat.fcp.client.renderer.Dpv.DpvMinigunRenderer;
import frontline.combat.fcp.client.renderer.Projectile.Hellfire.WireGuidedHellfireRenderer;
import frontline.combat.fcp.client.renderer.Projectile.Malyutka.MalyutkaRenderer;
import frontline.combat.fcp.client.renderer.Projectile.Sidewinder.SidewinderRenderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerM2Renderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerMGSRenderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerDragoonRenderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerMk19Renderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerTowRenderer;
import frontline.combat.fcp.client.renderer.Stryker.StrykerMortarRenderer;
import frontline.combat.fcp.client.renderer.T72av.T72AVRenderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxBMPRenderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxRenderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxRocketPodRenderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxSpg9Renderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxMortarRenderer;
import frontline.combat.fcp.client.renderer.Toyota.ToyotaHiluxZu23Renderer;
import frontline.combat.fcp.client.renderer.Trailers.ExampleTrailer.ExampleTrailerRenderer;
import frontline.combat.fcp.client.renderer.Uaz.UAZDSHKARenderer;
import frontline.combat.fcp.client.renderer.Uaz.UAZSPG9Renderer;
import frontline.combat.fcp.client.renderer.Uaz.UAZRenderer;
import frontline.combat.fcp.client.renderer.Uaz.UAZ452Renderer;
import frontline.combat.fcp.client.renderer.Uaz.UAZ3303Renderer;
import frontline.combat.fcp.client.renderer.Ural.UralGradRenderer;
import frontline.combat.fcp.client.renderer.Ural.UralRenderer;
import frontline.combat.fcp.client.renderer.Viper.ViperRenderer;
import frontline.combat.fcp.client.renderer.Oh1.Oh1Renderer;
import frontline.combat.fcp.client.renderer.Ch53.Ch53aRenderer;
import frontline.combat.fcp.client.renderer.Ch53.Ch53eRenderer;
import frontline.combat.fcp.client.renderer.Ch53.Mh53Renderer;
import frontline.combat.fcp.client.renderer.Uh60.Uh60Renderer;
import frontline.combat.fcp.client.renderer.Uh60.Uh60MinigunRenderer;
import frontline.combat.fcp.client.renderer.Uh60.Mh60lRenderer;
import frontline.combat.fcp.client.renderer.Projectile.Hellfire.LockOnHellfireRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import frontline.combat.fcp.client.overlay.FcpDriverOverlay;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;

@Mod.EventBusSubscriber(modid = FCP.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModEntityRenderers {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX.get(), ToyotaHiluxRenderer::new);
        event.registerEntityRenderer(ModEntities.DPV_M240.get(), DpvM240Renderer::new);
        event.registerEntityRenderer(ModEntities.DPV_MINIGUN.get(), DpvMinigunRenderer::new);
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX_ROCKET_POD.get(), ToyotaHiluxRocketPodRenderer::new);
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX_BMP.get(), ToyotaHiluxBMPRenderer::new);
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX_SPG9.get(), ToyotaHiluxSpg9Renderer::new);
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX_MORTAR.get(), ToyotaHiluxMortarRenderer::new);
        event.registerEntityRenderer(ModEntities.TOYOTA_HILUX_ZU23.get(), ToyotaHiluxZu23Renderer::new);

        event.registerEntityRenderer(ModEntities.UAZ.get(), UAZRenderer::new);
        event.registerEntityRenderer(ModEntities.UAZ_DSHKA.get(), UAZDSHKARenderer::new);
        event.registerEntityRenderer(ModEntities.UAZ_SPG9.get(), UAZSPG9Renderer::new);
        event.registerEntityRenderer(ModEntities.UAZ_452.get(), UAZ452Renderer::new);
        event.registerEntityRenderer(ModEntities.UAZ_3303.get(), UAZ3303Renderer::new);

        event.registerEntityRenderer(ModEntities.STRYKER_MGS.get(), StrykerMGSRenderer::new);
        event.registerEntityRenderer(ModEntities.STRYKER_M2.get(), StrykerM2Renderer::new);
        event.registerEntityRenderer(ModEntities.STRYKER_DRAGOON.get(), StrykerDragoonRenderer::new);
        event.registerEntityRenderer(ModEntities.STRYKER_MK19.get(), StrykerMk19Renderer::new);
        event.registerEntityRenderer(ModEntities.STRYKER_TOW.get(), StrykerTowRenderer::new);
        event.registerEntityRenderer(ModEntities.STRYKER_MORTAR.get(), StrykerMortarRenderer::new);

        event.registerEntityRenderer(ModEntities.LITTLEBIRD.get(), LittlebirdRenderer::new);
        event.registerEntityRenderer(ModEntities.LITTLEBIRD_ARMED.get(), LittlebirdArmedRenderer::new);
        event.registerEntityRenderer(ModEntities.AH6M_LITTLEBIRD.get(), Ah6mLittlebirdRenderer::new);

        event.registerEntityRenderer(ModEntities.BMP1.get(), BMP1Renderer::new);
        event.registerEntityRenderer(ModEntities.BMP1U.get(), BMP1URenderer::new);
        event.registerEntityRenderer(ModEntities.BMP1AM.get(), BMP1AMRenderer::new);

        event.registerEntityRenderer(ModEntities.BMP2.get(), BMP2Renderer::new);
        event.registerEntityRenderer(ModEntities.BMP1P.get(), BMP1PRenderer::new);
        event.registerEntityRenderer(ModEntities.BMP2D.get(), BMP2DRenderer::new);
        event.registerEntityRenderer(ModEntities.BMP2M.get(), BMP2MRenderer::new);
        event.registerEntityRenderer(ModEntities.BMP2_NOATGM.get(), BMP2NoAtgmRenderer::new);
        event.registerEntityRenderer(ModEntities.BMP2MD.get(), BMP2MDRenderer::new);

        event.registerEntityRenderer(ModEntities.AAVP.get(), AAVPRenderer::new);

        event.registerEntityRenderer(ModEntities.LAV25.get(), Lav25Renderer::new);

        event.registerEntityRenderer(ModEntities.T72AV.get(), T72AVRenderer::new);

        event.registerEntityRenderer(ModEntities.URAL.get(), UralRenderer::new);
        event.registerEntityRenderer(ModEntities.URAL_FUEL.get(), frontline.combat.fcp.client.renderer.Ural.UralFuelRenderer::new);
        event.registerEntityRenderer(ModEntities.URAL_KUNG.get(), frontline.combat.fcp.client.renderer.Ural.UralKungRenderer::new);
        event.registerEntityRenderer(ModEntities.URAL_GRAD.get(), UralGradRenderer::new);

        event.registerEntityRenderer(ModEntities.KAMAZ.get(), KamazRenderer::new);
        event.registerEntityRenderer(ModEntities.KAMAZ_KUNG.get(), frontline.combat.fcp.client.renderer.Kamaz.KamazKungRenderer::new);
        event.registerEntityRenderer(ModEntities.KAMAZ_LONG.get(), frontline.combat.fcp.client.renderer.Kamaz.KamazLongRenderer::new);

        event.registerEntityRenderer(ModEntities.VIPER.get(), ViperRenderer::new);
        event.registerEntityRenderer(ModEntities.OH1.get(), Oh1Renderer::new);
        event.registerEntityRenderer(ModEntities.CH53A.get(), Ch53aRenderer::new);
        event.registerEntityRenderer(ModEntities.CH53E.get(), Ch53eRenderer::new);
        event.registerEntityRenderer(ModEntities.MH53.get(), Mh53Renderer::new);
        event.registerEntityRenderer(ModEntities.UH60.get(), Uh60Renderer::new);
        event.registerEntityRenderer(ModEntities.UH60_MINIGUN.get(), Uh60MinigunRenderer::new);
        event.registerEntityRenderer(ModEntities.MH60L.get(), Mh60lRenderer::new);

        event.registerEntityRenderer(ModEntities.GAZ_TIGR.get(), GazTigrRenderer::new);
        event.registerEntityRenderer(ModEntities.GAZ_TIGR_RWS.get(), GazTigrRWSRenderer::new);
        event.registerEntityRenderer(ModEntities.GAZ_TIGR_MG.get(), GazTigrMGRenderer::new);
        event.registerEntityRenderer(ModEntities.GAZ_TIGR_GL.get(), GazTigrGLRenderer::new);
        event.registerEntityRenderer(ModEntities.GAZ_TIGR_DUAL.get(), GazTigrDualRenderer::new);

        event.registerEntityRenderer(ModEntities.HUEY.get(), HueyRenderer::new);
        event.registerEntityRenderer(ModEntities.HUEY_M60_DOOR_GUNS.get(), HueyM60DoorGunsRenderer::new);
        event.registerEntityRenderer(ModEntities.HUEY_M60_GUNSHIP.get(), HueyM60GunshipRenderer::new);
        event.registerEntityRenderer(ModEntities.HUEY_M134_DOOR_GUNS.get(), HueyM134DoorGunsRenderer::new);
        event.registerEntityRenderer(ModEntities.HUEY_M134_GUNSHIP.get(), HueyM134GunshipRenderer::new);
        event.registerEntityRenderer(ModEntities.VENOM.get(), VenomRenderer::new);
        event.registerEntityRenderer(ModEntities.VENOM_GUNSHIP.get(), VenomGunshipRenderer::new);
        event.registerEntityRenderer(ModEntities.VENOM_DOOR_GUNS.get(), VenomDoorGunsRenderer::new);

        event.registerEntityRenderer(ModEntities.NOVATOR.get(), NovatorRenderer::new);
        event.registerEntityRenderer(ModEntities.NOVATOR_UNARMED.get(), NovatorUnarmedRenderer::new);

        event.registerEntityRenderer(ModEntities.MATV.get(), MATVRenderer::new);
        event.registerEntityRenderer(ModEntities.RG_33.get(), RG33Renderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_TOW.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplTowRenderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_KORNET.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplKornetRenderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_DSHK.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplDshkRenderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_MK19.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplMk19Renderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_AGS17.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplAgs17Renderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_M2.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplM2Renderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_MG3.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplMg3Renderer::new);
        event.registerEntityRenderer(ModEntities.EMPL_ZIS3.get(), frontline.combat.fcp.client.renderer.Emplacement.EmplZis3Renderer::new);
        event.registerEntityRenderer(ModEntities.PANTSIR.get(), frontline.combat.fcp.client.renderer.Pantsir.PantsirRenderer::new);
        event.registerEntityRenderer(ModEntities.BRDM2.get(), frontline.combat.fcp.client.renderer.Brdm.Brdm2Renderer::new);
        event.registerEntityRenderer(ModEntities.M939.get(), frontline.combat.fcp.client.renderer.M939.M939Renderer::new);
        event.registerEntityRenderer(ModEntities.KOZAK5.get(), frontline.combat.fcp.client.renderer.Kozak.Kozak5Renderer::new);
        event.registerEntityRenderer(ModEntities.KOZAK2M1.get(), frontline.combat.fcp.client.renderer.Kozak.Kozak2m1Renderer::new);
        event.registerEntityRenderer(ModEntities.KOZAK_AMBULANCE.get(), frontline.combat.fcp.client.renderer.Kozak.KozakAmbulanceRenderer::new);
        event.registerEntityRenderer(ModEntities.MATV_TOW.get(), MATVTOWRenderer::new);
        event.registerEntityRenderer(ModEntities.MATV_CROW.get(), MATVCrowsRenderer::new);
        event.registerEntityRenderer(ModEntities.MATV_9IN1.get(), MATV9In1Renderer::new);

        event.registerEntityRenderer(ModEntities.HMMWV_AMBULANCE.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_ARMORED_M2.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_ARMORED_MK19.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_ARMORED_UNARMED.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_ASRAD.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_AVENGER.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_CARGO.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_SHELTER.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_SOFT_TOP.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_SOFT_TOP_NO_DOORS.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_M2.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_M2_SHIELD.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_M2_TURRET.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_TOW.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_TOW_TURRET.get(), HumveeUnarmedRenderer::new);
        event.registerEntityRenderer(ModEntities.HMMWV_UNARMORED_UNARMED.get(), HumveeUnarmedRenderer::new);

        event.registerEntityRenderer(ModEntities.BTR82.get(), BTR82Renderer::new);
        event.registerEntityRenderer(ModEntities.BTR82AT.get(), BTR82ATRenderer::new);
        event.registerEntityRenderer(ModEntities.BTR3E.get(), BTR3ERenderer::new);
        event.registerEntityRenderer(ModEntities.BTR4MV1.get(), BTR4MV1Renderer::new);
        event.registerEntityRenderer(ModEntities.BTR80.get(), BTR80Renderer::new);
        event.registerEntityRenderer(ModEntities.BTR80_COPE.get(), BTR80CopeRenderer::new);
        event.registerEntityRenderer(ModEntities.BTR82_COPE.get(), BTR82CopeRenderer::new);

        event.registerEntityRenderer(ModEntities.MI17.get(), MI17Renderer::new);

        event.registerEntityRenderer(ModEntities.FMTV.get(), FMTVRenderer::new);

        event.registerEntityRenderer(ModEntities.M109.get(), M109Renderer::new);

        event.registerEntityRenderer(ModEntities.MSTA.get(), MstaRenderer::new);

        event.registerEntityRenderer(ModEntities.JOHN_DEERE.get(), JohnDeereRenderer::new);
        event.registerEntityRenderer(ModEntities.COMBINE.get(), CombineRenderer::new);

        event.registerEntityRenderer(ModEntities.M1A1.get(), M1a1Renderer::new);
        event.registerEntityRenderer(ModEntities.M1A2.get(), M1a2Renderer::new);

        // Projectiles
        event.registerEntityRenderer(ModEntities.LOCK_ON_HELLFIRE.get(), LockOnHellfireRenderer::new);
        event.registerEntityRenderer(ModEntities.WIRE_GUIDED_HELLFIRE.get(), WireGuidedHellfireRenderer::new);

        event.registerEntityRenderer(ModEntities.SIDEWINDER.get(), SidewinderRenderer::new);

        event.registerEntityRenderer(ModEntities.MALYUTKA.get(), MalyutkaRenderer::new);

        // Meme Vehicles
        event.registerEntityRenderer(ModEntities.BIGBIRD.get(), BigBirdRenderer::new);
        event.registerEntityRenderer(ModEntities.T14_ARMATA.get(), WolfRenderer::new);
        // Trailers
        event.registerEntityRenderer(ModEntities.EXAMPLE_TRAILER.get(), ExampleTrailerRenderer::new);
        event.registerEntityRenderer(ModEntities.SEEDER.get(), SeederRenderer::new);
        event.registerEntityRenderer(ModEntities.CULTIVATOR.get(), CultivatorRenderer::new);
    }
    @SubscribeEvent
    public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll(FcpDriverOverlay.ID, FcpDriverOverlay.INSTANCE);
        event.registerBelowAll(FcpPilotOverlay.ID, FcpPilotOverlay.INSTANCE);
    }

}

